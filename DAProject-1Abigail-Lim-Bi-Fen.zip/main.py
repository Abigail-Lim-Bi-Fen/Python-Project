#########################################################################
#Title: PYTHON Project Scenario - Data Analysis
#Description: This program allows user to analyse.......
#Name: <Abigail Lim Bi Fen>
#Group Name: <PythonKings>
#Class: <PN2004K>
#Date: <15Feb2021>
#Version: <3.0>
#########################################################################

#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################
#import pandas for data analysis
import pandas as pd
from collections import Counter
import matplotlib.pyplot as plt
#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################

#########################################################################
#CLASS Branch - Data Analysis
#load excel data (CSV format) to dataframe
#########################################################################
class DataAnalysis:
  def __init__(self):

    #load excel data (CSV format) to dataframe - 'df'
    dataframe = pd.read_csv('MonthyVisitors.csv')
    #show specific country dataframe
    sortCountry(dataframe)
    #Initialize list and dictionary 
    time_list = ["1978-1987", "1988-1997", "1998-2007", "2008-2017"]#Time list used to cross refer for error checking
    region_list = ["1", "2", "3", "4", "5", "6", "7", "8"]#region list used to cross refer for error checking
    region_name_list = ["(1)South East Asia(SEA)", "(2)Asia South Pacific(ASP)","(3)South Asia Pacific(SAP)","(4)Middle East(ME)", "(5)Europe(EU)", "(6)North America(NA)","(7)Australia(AU)", "(8)Africa(AF)"]#Region name to show user region picked by them
    Travellers = []#To store travellers
    Total_Number_Of_Travellers= []#To store total travellers for each country
    Region_Countries=[]#To store every country from SEA
    Country_Visitor_dict={}#initialize dictionary country:travellers total
    Time_index = ["1978-1987","1988-1997","1998-2007","2008-2017"]

    Time_tuple = [(1,120),(120,240),(240,360),(360,480)]#tuple set of start date and end date
    
    region_index = ["1", "2", "3", "4", "5", "6", "7", "8"]

    region_tuple =[(2,9),(9,14),(14,17),(17,20),(20,31),(31,33),(33,35),(35,36)]#tuple set of start country and end country

    time_dict={Time_index[i]:Time_tuple[i]for i in range(len(Time_index))}

    region_dict={region_index[i]:region_tuple[i]for i in range(len(region_index))}

    region_name_dict = {region_list[i]:region_name_list [i]for i in range(len(region_list))}

    #load excel data (CSV format) to dataframe - 'df'
    df= pd.read_csv('MonthyVisitors.csv')
    #show specific country dataframe
    sortCountry(df)
    print("Select time period eg.(year-year)", "\n", "1978-1987", "\n",
          "1988-1997", "\n", "1998-2007", "\n", "2008-2017") 

    #While loop to use for error checking, if user input has no error it will break out of the loop else it will keeps on looping
    while True:
        User_time = input("select a time period:")
        if not User_time in time_list:
            print("Error!")
        elif User_time in time_list:
            break

    #calling the dictionary value
    g=time_dict[User_time]
    w = g[0]#calling first index of the tuple
    x = g[1]#calling second index of the tuple


    #cross reference to user input and assign values to variables
    print("Select a region:", "\n", "(1)South East Asia(SEA)", "\n",
          "(2)Asia South Pacific(ASP)", "\n", "(3)South Asia Pacific(SAP)",
          "\n", "(4)Middle East(ME)", "\n", "(5)Europe(EU)", "\n",
          "(6)North America(NA)", "\n", "(7)Australia(AU)", "\n",
          "(8)Africa(AF)")


    #While loop is use for error checking, if user input has no error it will break out of the loop else it wil carry on to loop
    while True:
        region = input("Enter a region. Enter 1 for SEA or 2 for ASP etc: ")
        region = str(region)
        if not region in region_list:
            print("Error!")
        elif region in region_list:
            break

    #calling the dictionary value
    h = region_dict[region]
    y = h[0]#calling first index of the tuple
    z = h[1]#calling second index of the tuple
    
    #specify the dataframe
    df = df.iloc[w:x, y:z]
    #number of countries = last country index (z) - first country index (y)
    countryrange = z-y
    #For every country in columns 2 to 9 of df.iloc[264:396,2:9]

    for country in df.columns[0:int(countryrange)]:
      #append country in the list
      Region_Countries.append(country)
      #append travellers to travellers list 
      for x in df[country]:
        Travellers.append(x)

    #Convert string to integer
    for a in range(0,len(Travellers)):
      #if element inside of [Travellers] change the na element to 0
      if Travellers[a] ==" na ":
        Travellers[a] = 0
      else:
        Travellers[a] =int(Travellers[a])


    #find out the total data
    number_of_data = len(Travellers)

    
    #find out how much data each country uses
    counter = number_of_data/len(Region_Countries)
    
    #initialize list and variable for travellers index
    indValue1 = 0
    indValue2 = int(counter)
     
    #length of region countries
    region_countries_range = len(Region_Countries)
    
    #while loop to sum each country travellers and appending it to total number of travellers
    while region_countries_range != 0:
      Total_Number_Of_Travellers.append(sum(Travellers[indValue1:indValue2]))
      indValue1=indValue1 + (int(counter))
      indValue2=indValue2 + (int(counter))
      region_countries_range = region_countries_range - 1
    
    #Create Dictionary based on countries as keys : total visitor as value
    Country_Visitor_dict = { Region_Countries[i]: Total_Number_Of_Travellers[i] for i in range(len(Region_Countries))}
    
    #Sort dictionary in descending order by it values and convert to list
    sort_Country_Visitor_dict = sorted(Country_Visitor_dict.items(), key=lambda x: x[1], reverse=True)
    
    #Convert list back to dictionary
    Country_Visitor_dict  = dict(sort_Country_Visitor_dict)
    
    k =Counter(Country_Visitor_dict)
    
    #To find the top 3 coutries with the most travellers by its value
    
    Top_3_Visitors = k.most_common(3)
    
    # Frame data using top 3 visitors tuple with columns "Country" and "Travellers"

    df = pd.DataFrame(Top_3_Visitors,columns = ["Country","Travellers"])
    
    #Print selected region and time frame

    print("Region selected:",region_name_dict[region],
    "\n","Time period selected:",User_time,"\n",
    "Dataframe representing top 3 countries with the most travllers from",region_name_dict[region],".","\n",
    df)
    
    #Initialize lists
    labels = []
    sizes = []
    #appending the list with values from the data frame
    for x in df["Country"]:
      labels.append(x)
    for y in df["Travellers"]:
      sizes.append(y)
    #initialize list and variable
    distance = 0.1
    seperate = []
    #for loop to append distance according to amount of region in countries
    for i in range(0, len(df['Travellers'])):
      seperate.append(distance)
    # Plot pie chart 
    plt.pie(sizes,labels=labels, explode=seperate, startangle=90, autopct='%1.2f%%',shadow=True)
    plt.axis('equal')
    #create legend
    plt.legend(loc="best")
    #Show pie chart
    plt.show()


#########################################################################
#FUNCTION Branch - sortCountry
#parses data and displays sorted result(s)
#########################################################################

def sortCountry(df):

  #print number of rows in dataframe
  print("There are " + str(len(df)) + " data rows read. \n")

  #display dataframe (rows and columns)
  print("The following dataframe are read as follows: \n")
  print(df)

  #display a specific country (Australia) in column #33
  country_label = df.columns[33]
  print("\n\n" + country_label + "was selected.")

  #display a sorted dataframe based on selected country
  print(" The" + country_label + "was sorted in ascending order. \n")
  sorted_df =df.sort_values(country_label,ascending=[0]) 
  
#########################################################################
#FUNCTION Branch: End of Code
#########################################################################

#########################################################################
#CLASS Branch: End of Code
#########################################################################

#########################################################################
#Main Branch
#########################################################################
if __name__ == '__main__':
  
  #Project Title
  print('######################################')
  print('# Data Analysis App - PYTHON Project #')
  print('######################################')

  #perform data analysis on specific excel (CSV) file
  DataAnalysis()

#########################################################################
#Main Branch: End of Code
#########################################################################